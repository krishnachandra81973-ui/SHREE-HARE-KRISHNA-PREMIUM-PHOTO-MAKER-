/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import { 
  Upload, 
  Printer, 
  Trash2, 
  Plus, 
  Minus, 
  Settings2, 
  Image as ImageIcon,
  Loader2,
  Check,
  Download,
  Crop
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import html2canvas from 'html2canvas';
import Cropper from 'react-easy-crop';
import getCroppedImg from './utils/cropImage';

// Constants for Passport Size (Standard 3.5cm x 4.5cm)
const PASSPORT_WIDTH_MM = 35;
const PASSPORT_HEIGHT_MM = 45;
const A4_WIDTH_MM = 210;
const A4_HEIGHT_MM = 297;
const DPI = 96; // Standard screen DPI for preview, we'll use mm for printing

export default function App() {
  const [rawImage, setRawImage] = useState<string | null>(null);
  const [showCropper, setShowCropper] = useState(false);
  const [crop, setCrop] = useState({ x: 0, y: 0 });
  const [zoom, setZoom] = useState(1);
  const [croppedAreaPixels, setCroppedAreaPixels] = useState(null);

  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [processedImage, setProcessedImage] = useState<string | null>(null);
  const [photoWidth, setPhotoWidth] = useState(33);
  const [photoHeight, setPhotoHeight] = useState(42);
  const [isEnhancing, setIsEnhancing] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const [borderThickness, setBorderThickness] = useState(1);
  const [photoGap, setPhotoGap] = useState(2);
  const [pageMargin, setPageMargin] = useState(1);
  const [photoCount, setPhotoCount] = useState(6);
  const [brightness, setBrightness] = useState(100);
  const [photoBgColor, setPhotoBgColor] = useState('#FFFFFF');
  const [error, setError] = useState<string | null>(null);
  const [studioLogo, setStudioLogo] = useState<string | null>(() => localStorage.getItem('studioLogo') || null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const logoInputRef = useRef<HTMLInputElement>(null);

  const bokehElements = useMemo(() => {
    return Array.from({ length: 20 }).map((_, i) => ({
      id: i,
      left: `${Math.random() * 100}%`,
      top: `${Math.random() * 100}%`,
      size: Math.random() * 150 + 50,
      duration: Math.random() * 20 + 15,
      delay: Math.random() * 5,
      opacity: Math.random() * 0.4 + 0.1,
    }));
  }, []);

  const handleLogoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const result = event.target?.result as string;
        setStudioLogo(result);
        localStorage.setItem('studioLogo', result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setRawImage(event.target?.result as string);
        setShowCropper(true);
        setSelectedImage(null);
        setProcessedImage(null);
        setZoom(1);
        setCrop({ x: 0, y: 0 });
      };
      reader.readAsDataURL(file);
    }
  };

  const onCropComplete = useCallback((croppedArea: any, croppedAreaPixels: any) => {
    setCroppedAreaPixels(croppedAreaPixels);
  }, []);

  const handleCropSave = async () => {
    if (rawImage && croppedAreaPixels) {
      try {
        const croppedImage = await getCroppedImg(rawImage, croppedAreaPixels);
        setSelectedImage(croppedImage);
        setShowCropper(false);
      } catch (e) {
        console.error(e);
        setError("Failed to crop image.");
      }
    }
  };

  const removeBackground = async () => {
    if (!selectedImage) return;
    
    setIsProcessing(true);
    setError(null);
    
    try {
      const res = await fetch('/api/remove-background', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          image: selectedImage,
          bgColor: photoBgColor,
        }),
      });

      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.error || "Background removal failed.");
      }

      const data = await res.json();

      if (data.imageUrl) {
        setProcessedImage(data.imageUrl);
      } else {
        throw new Error("Failed to process image. Please try again.");
      }
    } catch (err: any) {
      console.error(err);
      setError("Error removing background. Using original image instead.");
      setProcessedImage(selectedImage);
    } finally {
      setIsProcessing(false);
    }
  };

  const enhancePhoto = async () => {
    if (!selectedImage && !processedImage) return;
    
    setIsEnhancing(true);
    setError(null);
    
    try {
      const res = await fetch('/api/enhance-photo', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          image: processedImage || selectedImage,
        }),
      });

      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.error || "Enhancement failed.");
      }

      const data = await res.json();

      if (data.imageUrl) {
        setProcessedImage(data.imageUrl);
      } else {
        throw new Error("Failed to enhance image.");
      }
    } catch (err: any) {
      console.error(err);
      setError("Enhancement failed. Please try again.");
    } finally {
      setIsEnhancing(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const handleDownload = async () => {
    const printArea = document.getElementById('a4-container');
    if (!printArea) return;
    
    setIsDownloading(true);
    const watermark = document.getElementById('watermark');
    if (watermark) watermark.style.display = 'none';
    
    try {
      const canvas = await html2canvas(printArea, {
        scale: 3,
        useCORS: true,
        backgroundColor: '#ffffff',
      });
      
      const image = canvas.toDataURL('image/jpeg', 0.95);
      const link = document.createElement('a');
      link.href = image;
      link.download = `Shree-Hare-Krishna-A4-${Date.now()}.jpg`;
      link.click();
    } catch (err) {
      console.error(err);
      setError("Failed to generate high-res image.");
    } finally {
      if (watermark) watermark.style.display = 'flex';
      setIsDownloading(false);
    }
  };

  return (
    <div className="min-h-screen animated-bg text-white font-sans selection:bg-sky-500/30 relative overflow-x-hidden">
      {/* Animated Background Visualizations */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
        {/* Bokeh Elements */}
        {bokehElements.map((p) => (
          <motion.div
            key={p.id}
            className="absolute rounded-full bg-white mix-blend-overlay"
            initial={{
              left: p.left,
              top: p.top,
              y: 0,
              x: 0,
              scale: 0.8,
            }}
            animate={{
              y: [0, -150, 0],
              x: [0, 100, 0],
              scale: [0.8, 1.2, 0.8],
            }}
            transition={{
              duration: p.duration,
              repeat: Infinity,
              ease: "easeInOut",
              delay: p.delay,
            }}
            style={{
              width: `${p.size}px`,
              height: `${p.size}px`,
              opacity: p.opacity,
              filter: `blur(${p.size / 5}px)`,
            }}
          />
        ))}

        <motion.div
          animate={{ scale: [1, 1.2, 1], opacity: [0.4, 0.6, 0.4] }}
          transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
          className="absolute -top-[20%] -left-[10%] w-[50vw] h-[50vw] rounded-full bg-blue-600/40 blur-[120px]"
        />
        <motion.div
          animate={{ scale: [1, 1.5, 1], opacity: [0.3, 0.5, 0.3] }}
          transition={{ duration: 10, repeat: Infinity, ease: "easeInOut", delay: 2 }}
          className="absolute top-[40%] -right-[10%] w-[40vw] h-[40vw] rounded-full bg-indigo-600/30 blur-[100px]"
        />
      </div>

      <div className="relative z-10">
        {/* Cropper Modal */}
        <AnimatePresence>
          {showCropper && rawImage && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-[100] flex items-center justify-center bg-black/90 backdrop-blur-sm p-4"
            >
              <motion.div 
                initial={{ scale: 0.95, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.95, opacity: 0 }}
                className="glass-panel p-6 w-full max-w-2xl flex flex-col gap-6 rounded-2xl"
              >
                <div className="flex justify-between items-center">
                  <h3 className="text-xs font-bold uppercase tracking-widest text-sky-500 flex items-center gap-2">
                    <Crop size={16} /> Crop Photo
                  </h3>
                  <button onClick={() => setShowCropper(false)} className="text-slate-400 hover:text-white uppercase text-[10px] tracking-widest font-bold">Cancel</button>
                </div>
                <div className="relative w-full h-[50vh] bg-white rounded-2xl overflow-hidden border border-slate-200">
                  <Cropper
                    image={rawImage}
                    crop={crop}
                    zoom={zoom}
                    aspect={photoWidth / photoHeight}
                    onCropChange={setCrop}
                    onCropComplete={onCropComplete}
                    onZoomChange={setZoom}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold uppercase tracking-widest text-slate-300">Zoom</label>
                  <input
                    type="range"
                    value={zoom}
                    min={1}
                    max={3}
                    step={0.1}
                    onChange={(e) => setZoom(Number(e.target.value))}
                    className="w-full h-[2px] bg-white/20 appearance-none cursor-pointer accent-sky-500 rounded-full"
                  />
                </div>
                <button
                  onClick={handleCropSave}
                  className="w-full blue-gradient text-white py-4 text-xs font-bold uppercase tracking-widest hover:opacity-100 hover:shadow-[0_12px_40px_rgba(14,165,233,0.3)] hover:-translate-y-0.5 transition-all duration-300 shadow-[0_8px_30px_rgba(14,165,233,0.2)] rounded-2xl"
                >
                  Apply Crop
                </button>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Premium Header */}
        <header className="bg-slate-950/80 backdrop-blur-2xl border border-white/10 shadow-2xl py-6 px-10 sticky top-4 z-50 mx-4 mt-4 rounded-3xl">
          <div className="max-w-7xl mx-auto flex justify-between items-center">
            <div className="flex items-center gap-6">
              <div 
                className="relative w-24 h-24 rounded-full bg-white flex items-center justify-center overflow-hidden border border-sky-200 shadow-[0_10px_40px_rgba(14,165,233,0.15)] shrink-0 cursor-pointer group"
                onClick={() => logoInputRef.current?.click()}
              >
                <input 
                  type="file" 
                  ref={logoInputRef} 
                  onChange={handleLogoChange} 
                  className="hidden" 
                  accept="image/*"
                />
                <img 
                  src={studioLogo || "/logo.png"} 
                  alt="SHREE HARE KRISHNA Logo" 
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" 
                  onError={(e) => { e.currentTarget.src = 'https://placehold.co/200x200/0A0A0A/BF953F?text=M'; }} 
                />
                <div className="absolute inset-0 bg-white/10 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity duration-300">
                  <span className="text-[8px] font-bold uppercase tracking-widest text-sky-500">Change Logo</span>
                </div>
              </div>
              <div className="space-y-2">
                <h1 className="text-4xl font-sans font-bold tracking-tight text-white drop-shadow-sm">
                  SHREE HARE KRISHNA
                </h1>
                <div className="flex items-center gap-4">
                  <div className="h-[1px] w-12 blue-gradient opacity-50"></div>
                  <p className="text-[11px] font-sans font-medium uppercase tracking-[0.2em] text-slate-400">
                    Premium Quality Prints
                  </p>
                </div>
              </div>
            </div>
          <div className="flex flex-col items-end gap-3">
            <div className="flex gap-4">
              <button 
                onClick={handleDownload}
                disabled={!selectedImage || isDownloading}
                className="group relative flex items-center gap-3 bg-white/10 border border-white/10 text-white px-8 py-4 rounded-2xl font-sans font-medium uppercase tracking-widest text-xs hover:bg-white/20 hover:shadow-[0_8px_30px_rgba(255,255,255,0.05)] hover:-translate-y-0.5 transition-all duration-300 disabled:opacity-20 disabled:grayscale disabled:hover:translate-y-0"
              >
                {isDownloading ? <Loader2 className="animate-spin" size={16} /> : <Download size={16} />}
                Save A4 Image
              </button>
              <button 
                onClick={handlePrint}
                disabled={!selectedImage}
                className="group relative flex items-center gap-3 blue-gradient text-white px-10 py-4 rounded-2xl font-sans font-bold uppercase tracking-widest text-xs hover:opacity-100 hover:shadow-[0_15px_50px_rgba(14,165,233,0.35)] hover:-translate-y-0.5 transition-all duration-300 disabled:opacity-20 disabled:grayscale disabled:hover:translate-y-0 shadow-[0_10px_40px_rgba(14,165,233,0.25)]"
              >
                <Printer size={16} />
                Print
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto p-10 grid grid-cols-1 lg:grid-cols-12 gap-12">
        {/* Controls Sidebar */}
        <motion.aside 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="lg:col-span-4 space-y-8"
        >
          {/* Step 1: Upload */}
          <section className="glass-panel p-8 relative overflow-hidden group rounded-2xl">
            <div className="absolute top-0 left-0 w-1 h-full blue-gradient opacity-50"></div>
            <h2 className="text-[11px] font-sans font-bold uppercase tracking-[0.3em] text-slate-300 mb-8 flex items-center gap-3">
              <span className="w-6 h-6 rounded-full border border-sky-300 flex items-center justify-center text-[8px] text-sky-500">01</span>
              Capture Essence
            </h2>
            
            <div 
              onClick={() => fileInputRef.current?.click()}
              className={`relative border border-white/10 aspect-[4/3] flex flex-col items-center justify-center cursor-pointer transition-all overflow-hidden rounded-2xl ${
                selectedImage ? 'bg-white' : 'hover:bg-white/10 hover:border-sky-300'
              }`}
            >
              <input 
                type="file" 
                ref={fileInputRef} 
                onChange={handleFileChange} 
                className="hidden" 
                accept="image/*"
              />
              {selectedImage ? (
                <div className="relative w-full h-full group/img">
                  <img src={selectedImage} alt="Preview" className="w-full h-full object-cover opacity-80 group-hover/img:opacity-100 transition-opacity" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover/img:opacity-100 flex items-end p-4 transition-all">
                    <p className="text-[10px] font-bold uppercase tracking-widest text-sky-500">Replace Subject</p>
                  </div>
                </div>
              ) : (
                <div className="text-center space-y-4">
                  <Upload size={32} className="mx-auto text-sky-400/60" strokeWidth={1} />
                  <p className="text-[10px] font-bold uppercase tracking-tight text-slate-500">Select High-Res Portrait</p>
                </div>
              )}
            </div>

            {selectedImage && (
              <div className="space-y-3 mt-6">
                <button
                  onClick={removeBackground}
                  disabled={isProcessing}
                  className="w-full flex items-center justify-center gap-3 bg-white/10 border border-white/10 text-white py-4 text-[10px] font-bold uppercase tracking-tight hover:bg-white/20 hover:shadow-[0_8px_20px_rgba(255,255,255,0.05)] hover:-translate-y-0.5 transition-all duration-300 disabled:opacity-20 disabled:hover:translate-y-0 rounded-2xl"
                >
                  {isProcessing ? (
                    <Loader2 className="animate-spin text-sky-500" size={16} />
                  ) : processedImage ? (
                    <Check className="text-sky-500" size={16} />
                  ) : (
                    <Settings2 className="text-sky-500/60" size={16} />
                  )}
                  {isProcessing ? "Refining Subject..." : processedImage ? "Subject Isolated" : "AI Background Removal"}
                </button>

                <button
                  onClick={enhancePhoto}
                  disabled={isEnhancing}
                  className="w-full flex items-center justify-center gap-3 bg-sky-900/30 border border-sky-500/30 text-sky-500 py-4 text-[10px] font-bold uppercase tracking-tight hover:bg-sky-800/50 hover:shadow-[0_8px_20px_rgba(14,165,233,0.1)] hover:-translate-y-0.5 transition-all duration-300 disabled:opacity-20 disabled:hover:translate-y-0 rounded-2xl"
                >
                  {isEnhancing ? (
                    <Loader2 className="animate-spin" size={16} />
                  ) : (
                    <Download className="rotate-180" size={16} />
                  )}
                  {isEnhancing ? "Enhancing Quality..." : "AI Quality Enhance"}
                </button>
              </div>
            )}
            
            {error && <p className="text-red-500 text-[10px] mt-4 text-center tracking-wider">{error}</p>}
          </section>

          {/* Step 2: Precision Controls */}
          <section className="glass-panel p-8 relative rounded-2xl">
            <div className="absolute top-0 left-0 w-1 h-full blue-gradient opacity-50"></div>
            <h2 className="text-[11px] font-sans font-bold uppercase tracking-[0.3em] text-slate-300 mb-10 flex items-center gap-3">
              <span className="w-6 h-6 rounded-full border border-sky-500/30 flex items-center justify-center text-[8px] text-sky-500">02</span>
              Precision Tuning
            </h2>
            
            <div className="space-y-10">
              {/* Photo Dimensions */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-4">
                  <div className="flex justify-between items-end">
                    <label className="text-[10px] font-bold uppercase tracking-widest text-slate-300">Width</label>
                    <span className="text-[10px] font-mono text-sky-500">{photoWidth}mm</span>
                  </div>
                  <input 
                    type="range" min="20" max="100" step="1" value={photoWidth}
                    onChange={(e) => setPhotoWidth(parseInt(e.target.value))}
                    className="w-full h-[2px] bg-white/20 appearance-none cursor-pointer accent-sky-500 rounded-full"
                  />
                </div>
                <div className="space-y-4">
                  <div className="flex justify-between items-end">
                    <label className="text-[10px] font-bold uppercase tracking-widest text-slate-300">Height</label>
                    <span className="text-[10px] font-mono text-sky-500">{photoHeight}mm</span>
                  </div>
                  <input 
                    type="range" min="20" max="150" step="1" value={photoHeight}
                    onChange={(e) => setPhotoHeight(parseInt(e.target.value))}
                    className="w-full h-[2px] bg-white/20 appearance-none cursor-pointer accent-sky-500 rounded-full"
                  />
                </div>
              </div>

              {/* Border */}
              <div className="space-y-4">
                <div className="flex justify-between items-end">
                  <label className="text-[10px] font-bold uppercase tracking-widest text-slate-300">Border Weight</label>
                  <span className="text-[10px] font-mono text-sky-500">{borderThickness}pt</span>
                </div>
                <input 
                  type="range" min="0" max="10" step="0.5" value={borderThickness}
                  onChange={(e) => setBorderThickness(parseFloat(e.target.value))}
                  className="w-full h-[2px] bg-white/20 appearance-none cursor-pointer accent-sky-500 rounded-full"
                />
              </div>

              {/* Brightness */}
              <div className="space-y-4">
                <div className="flex justify-between items-end">
                  <label className="text-[10px] font-bold uppercase tracking-widest text-slate-300">Brightness</label>
                  <span className="text-[10px] font-mono text-sky-500">{brightness}%</span>
                </div>
                <input 
                  type="range" min="50" max="150" step="1" value={brightness}
                  onChange={(e) => setBrightness(parseInt(e.target.value))}
                  className="w-full h-[2px] bg-white/20 appearance-none cursor-pointer accent-sky-500 rounded-full"
                />
              </div>

              {/* Photo Background Color */}
              <div className="space-y-4">
                <div className="flex justify-between items-end">
                  <label className="text-[10px] font-bold uppercase tracking-widest text-slate-300">Background Color</label>
                  <span className="text-[10px] font-mono text-sky-500">{photoBgColor}</span>
                </div>
                <div className="flex gap-3">
                  {['#FFFFFF', '#0000FF', '#FF0000', '#87CEEB', '#000000'].map(color => (
                    <button
                      key={color}
                      onClick={() => setPhotoBgColor(color)}
                      className={`w-8 h-8 rounded-full border-2 transition-all duration-300 ${photoBgColor === color ? 'border-sky-500 scale-110 shadow-[0_0_15px_rgba(14,165,233,0.4)]' : 'border-slate-300/50 hover:border-sky-400 hover:scale-105'}`}
                      style={{ backgroundColor: color }}
                    />
                  ))}
                  <div className="relative w-8 h-8 rounded-full overflow-hidden border-2 border-slate-300/50 hover:border-sky-400 hover:scale-105 transition-all duration-300">
                    <input 
                      type="color" 
                      value={photoBgColor}
                      onChange={(e) => setPhotoBgColor(e.target.value)}
                      className="absolute -top-2 -left-2 w-12 h-12 cursor-pointer"
                    />
                  </div>
                </div>
                <p className="text-[9px] text-slate-400 uppercase tracking-widest mt-2">*Requires re-running AI Background Removal to apply</p>
              </div>

              {/* Photo Spacing */}
              <div className="space-y-4">
                <div className="flex justify-between items-end">
                  <label className="text-[10px] font-bold uppercase tracking-widest text-slate-300">Inter-Photo Gap</label>
                  <span className="text-[10px] font-mono text-sky-500">{photoGap}mm</span>
                </div>
                <input 
                  type="range" min="0" max="20" step="1" value={photoGap}
                  onChange={(e) => setPhotoGap(parseInt(e.target.value))}
                  className="w-full h-[2px] bg-white/20 appearance-none cursor-pointer accent-sky-500 rounded-full"
                />
              </div>

              {/* Page Margin */}
              <div className="space-y-4">
                <div className="flex justify-between items-end">
                  <label className="text-[10px] font-bold uppercase tracking-widest text-slate-300">Canvas Margin</label>
                  <span className="text-[10px] font-mono text-sky-500">{pageMargin}mm</span>
                </div>
                <input 
                  type="range" min="1" max="50" step="1" value={pageMargin}
                  onChange={(e) => setPageMargin(parseInt(e.target.value))}
                  className="w-full h-[2px] bg-white/20 appearance-none cursor-pointer accent-sky-500 rounded-full"
                />
              </div>

              {/* Quantity */}
              <div className="space-y-4">
                <label className="text-[10px] font-bold uppercase tracking-widest text-slate-300 block">Quantity</label>
                <div className="flex items-center gap-1">
                  <button 
                    onClick={() => setPhotoCount(Math.max(1, photoCount - 1))}
                    className="w-12 h-12 border border-white/10 flex items-center justify-center hover:bg-white/20 hover:text-sky-500 hover:shadow-[0_4px_15px_rgba(255,255,255,0.05)] transition-all duration-300 rounded-l-xl"
                  >
                    <Minus size={14} />
                  </button>
                  <div className="flex-1 h-12 flex items-center justify-center font-mono text-lg font-light bg-white/10 border-y border-white/10 shadow-inner">
                    {photoCount.toString().padStart(2, '0')}
                  </div>
                  <button 
                    onClick={() => setPhotoCount(photoCount + 1)}
                    className="w-12 h-12 border border-white/10 flex items-center justify-center hover:bg-white/20 hover:text-sky-500 hover:shadow-[0_4px_15px_rgba(255,255,255,0.05)] transition-all duration-300 rounded-r-xl"
                  >
                    <Plus size={14} />
                  </button>
                </div>
              </div>
            </div>
          </section>
        </motion.aside>

        {/* Preview Area */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2, ease: "easeOut" }}
          className="lg:col-span-8 flex flex-col items-center"
        >
          <div className="mb-6 flex items-center gap-4">
            <div className="h-[1px] w-12 bg-white/10"></div>
            <span className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-300">A4 Master Template</span>
            <div className="h-[1px] w-12 bg-white/10"></div>
          </div>

          <div 
            id="a4-container"
            className="bg-white shadow-[0_30px_80px_-10px_rgba(14,165,233,0.15)] relative overflow-hidden rounded-sm"
            style={{
              width: `${A4_WIDTH_MM}mm`,
              height: `${A4_HEIGHT_MM}mm`,
              boxSizing: 'border-box',
              backgroundColor: '#FFFFFF'
            }}
          >
            {/* Watermark */}
            <div id="watermark" className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-[0.02] rotate-[-45deg] select-none">
              <span className="text-[120px] font-sans font-black text-black tracking-tighter">SHREE HARE KRISHNA</span>
            </div>

            <div 
              id="print-area"
              className="w-full h-full grid grid-cols-6 content-start"
              style={{
                padding: `${pageMargin}mm`,
                gap: `${photoGap}mm`,
                boxSizing: 'border-box'
              }}
            >
              <AnimatePresence>
                {Array.from({ length: photoCount }).map((_, i) => (
                  <motion.div 
                    key={i}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.02 }}
                    className="relative bg-white"
                    style={{
                      width: `${photoWidth}mm`,
                      height: `${photoHeight}mm`,
                      border: borderThickness > 0 ? `${borderThickness}px solid black` : 'none',
                      boxSizing: 'border-box',
                      justifySelf: 'center'
                    }}
                  >
                    {(processedImage || selectedImage) ? (
                      <img 
                        src={processedImage || selectedImage || ''} 
                        alt="Passport" 
                        className="w-full h-full object-cover"
                        style={{ filter: `brightness(${brightness}%)` }}
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center border border-slate-200">
                        <ImageIcon size={16} className="text-black/5" />
                      </div>
                    )}
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </div>

          <div className="mt-12 flex items-center gap-8 text-slate-300 text-[9px] font-bold uppercase tracking-[0.3em]">
            <p>ISO/IEC 19794-5 Compliant</p>
            <div className="w-1 h-1 rounded-full bg-white/10"></div>
            <p>{photoWidth}mm x {photoHeight}mm Format</p>
            <div className="w-1 h-1 rounded-full bg-white/10"></div>
            <p>A4 Output Format</p>
          </div>
        </motion.div>
      </main>

      {/* Print Styles */}
      <style dangerouslySetInnerHTML={{ __html: `
        @media print {
          body * {
            visibility: hidden;
          }
          #print-area, #print-area * {
            visibility: visible;
          }
          #print-area {
            position: absolute;
            left: 0;
            top: 0;
            margin: 0;
            padding: ${pageMargin}mm !important;
            gap: ${photoGap}mm !important;
            box-shadow: none !important;
            width: 210mm !important;
            height: 297mm !important;
            background: white !important;
            display: grid !important;
            grid-template-columns: repeat(6, 1fr) !important;
            content-start: start !important;
          }
          @page {
            size: A4;
            margin: 0;
          }
          .absolute.inset-0.flex.items-center.justify-center.pointer-events-none {
            display: none !important;
          }
        }
      `}} />
      </div>
    </div>
  );
}
